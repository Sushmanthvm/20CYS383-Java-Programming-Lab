package com.amrita.jpl.u4cys21077.practise;

import java.util.Scanner;

public class Sum {
    public static void main(String[] args) {
        int n1, n2, sum;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter First number: ");
        n1=sc.nextInt();

        System.out.println("Enter Second number: ");
        n2=sc.nextInt();

        sc.close();
        sum = n1+n2;

        System.out.println("The Sum of numbers is:" + sum);
    }
}