package com.amrita.jpl.u4cys21077.excersie;

abstract class FileTransfer {
    abstract void saveFile(byte[] fileData, String filename);

    void sendFile(String filename) {
        System.out.println("Sending file: " + filename);
    }
}