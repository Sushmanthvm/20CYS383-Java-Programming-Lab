package com.amrita.jpl.u4cys21077.P1;
import java.util.Scanner;

import static com.amrita.jpl.u4cys21077.P1.Menu.fact;
import static com.amrita.jpl.u4cys21077.P1.Menu.fibo;

/**
 * @author Sushmanth.V.M (CB.EN.U4CYS21077)
 */

/**
 * @exception Main class
 */
public class Main {


    /**
     * @param args none
     * @description 
     */
    public static void main(String[] args) {

        int choice,val;
        Scanner my_scanner = new Scanner(System.in);
        Menu obj = new Menu();

        /**
         * @exception Menu
         * @description displays the menu
         */

        while(true){

            System.out.println("--------MENU---------");
            System.out.println("1.Factorial");
            System.out.println("2.Fibonacci");
            System.out.println("3.Sum of n numbers");
            System.out.println("4.Prime Test");
            System.out.println("-----------------------");
            System.out.println("Enter your choice");
            choice = my_scanner.nextInt();

            switch (choice){
                case 1:
                    System.out.println("Enter a value");
                    val= my_scanner.nextInt();
                    System.out.println(fact(val));
                    break;

                case 2:
                    System.out.println("Enter a value");
                    val= my_scanner.nextInt();
                    fibo(val);
                    break;

                case 3:
                    System.out.println("Enter a value");
                    val= my_scanner.nextInt();
                    System.out.println(obj.sum_n_no(val));
                    break;


                case 4:
                    System.out.println("Enter a value");
                    val= my_scanner.nextInt();

                    if(obj.prime_test(val) == true)
                        System.out.println(val+"is a prime number");
                    else
                        System.out.println(val+"is a composite number");


                    break;

                default:
                    System.out.println("Enter a valid input!!!!");


            }

        }




    }
}