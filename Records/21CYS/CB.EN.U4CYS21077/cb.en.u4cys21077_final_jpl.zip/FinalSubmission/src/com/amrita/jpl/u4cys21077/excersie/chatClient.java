package com.amrita.jpl.u4cys21077.excersie;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class chatClient {
    static public void main(String arg[]){
        try{
            Socket s = new Socket("localhost",2345);

            DataInputStream din = new DataInputStream(s.getInputStream());
            DataOutputStream dout = new DataOutputStream(s.getOutputStream());

            Scanner get = new Scanner(System.in);
            String recevied = null;

            do {

                recevied = din.readUTF();
                System.out.println("Message form Server : " + recevied);

                 String send = get.nextLine();
                dout.writeUTF(send);
                dout.flush();


            } while(recevied != "Exit");

            // Close the output stream and the socket

            dout.close();
            s.close();

        }
        catch(IOException e){
            System.out.println("An error occurred");
        }

    }

}
