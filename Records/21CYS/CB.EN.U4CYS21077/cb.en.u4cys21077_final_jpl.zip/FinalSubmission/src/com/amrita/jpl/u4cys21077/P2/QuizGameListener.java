package com.amrita.jpl.u4cys21077.P2;
/**
 * Interface
 * @author Sushmanth.V.M
 * Refered ChatClient.java ChatServer.java
 */
public interface QuizGameListener {
    void onQuestionAsked(String question);

    void onAnswerEvaluated(boolean isCorrect);
}

