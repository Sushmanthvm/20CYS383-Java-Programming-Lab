package com.amrita.jpl.u4cys21077.excersie;

interface FileTransferListener {
    void onFileSent(String filename);

    void onFileSaved(String filename);
}
