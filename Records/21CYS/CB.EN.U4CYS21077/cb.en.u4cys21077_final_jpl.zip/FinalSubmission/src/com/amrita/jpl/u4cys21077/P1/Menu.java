package com.amrita.jpl.u4cys21077.P1;

public class Menu {

    /**
     *
     * @param n
     * @return fact
     * @description user gives a value and factorial is calcu
     */
    static int fact(int n)
    {
        int i,fact=1;

        for(i=1;i<=n;i++)
        {
            fact=fact*i;
        }



        return fact;

    }


    /**
     *
     * @param n
     *
     */
    static void fibo( int n)
    {
        int a=0,b=1,c=0,i;

        System.out.println(a);
        System.out.println(b);


        for(i=3;i<=n;i++)
        {
            c=a+b;
            a=b;
            b=c;
            System.out.println(c);

        }

    }

    /**
     *
     * @param n
     * @return sum
     */
    public int sum_n_no(int n)
    {
        int sum=0,i;
        for(i=1;i<=n;i++)
        {
            sum=sum+i;
        }

        return sum;
    }

    /**
     *
     * @param n
     * @return true or false
     */
    public boolean prime_test(int n){
        int i,count=0;

        for(i=1;i<=n;i++)
        {
            if(n%i==0)
                count+=1;


        }

        if(count == 2)
            return true;
        else
            return false;

    }
}
