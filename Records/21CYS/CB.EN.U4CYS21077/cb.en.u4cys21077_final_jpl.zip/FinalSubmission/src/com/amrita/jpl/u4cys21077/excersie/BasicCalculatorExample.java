package com.amrita.jpl.u4cys21077.excersie;

// Interface Calculator
interface Calculator {
    double add(double num1, double num2);
    double subtract(double num1, double num2);
    double multiply(double num1, double num2);
    double divide(double num1, double num2);
}

// Class BasicCalculator implementing the Calculator interface
class BasicCalculator implements Calculator {
    @Override
    public double add(double num1, double num2) {
        return num1 + num2;
    }

    @Override
    public double subtract(double num1, double num2) {
        return num1 - num2;
    }

    @Override
    public double multiply(double num1, double num2) {
        return num1 * num2;
    }

    @Override
    public double divide(double num1, double num2) {
        if (num2 == 0) {
            System.out.println("Error: Division by zero is not allowed.");
            return 0; // or any other appropriate error handling logic
        } else {
            return num1 / num2;
        }
    }
}

// Class BasicCalculatorExample
public class BasicCalculatorExample {
    public static void main(String[] args) {
        BasicCalculator calculator = new BasicCalculator();

        // Perform operations
        double sum = calculator.add(5.2, 3.8);
        System.out.println("Sum: " + sum);

        double difference = calculator.subtract(10.5, 4.2);
        System.out.println("Difference: " + difference);

        double product = calculator.multiply(2.5, 3);
        System.out.println("Product: " + product);

        double quotient = calculator.divide(10, 0); // Division by zero
        System.out.println("Quotient: " + quotient);
    }
}

