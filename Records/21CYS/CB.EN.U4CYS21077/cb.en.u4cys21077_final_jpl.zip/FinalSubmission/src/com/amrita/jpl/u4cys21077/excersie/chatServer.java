package com.amrita.jpl.u4cys21077.excersie;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class chatServer {
    public static void main(String args[]){
        try{
            ServerSocket ss = new ServerSocket(2345);
            Socket s = ss.accept();

            DataInputStream din = new DataInputStream(s.getInputStream());
            DataOutputStream dout = new DataOutputStream(s.getOutputStream());

            Scanner get = new Scanner(System.in);
            dout.writeUTF("Hello client");
            dout.flush();

            while(true){
                String received = din.readUTF();

                System.out.println("Message from client : " + received);

                if(received.equals("exit")){
                    break;
                }

                String send = get.nextLine();
                dout.writeUTF(send);
                dout.flush();

            }

            din.close();
            dout.close();
            ss.close();


        }

        catch(Exception e){
            System.out.println("An Error occurred ");

        }
    }
}
