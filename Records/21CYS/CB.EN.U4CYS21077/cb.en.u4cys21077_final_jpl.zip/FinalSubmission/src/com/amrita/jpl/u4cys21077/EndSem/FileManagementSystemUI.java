package com.amrita.jpl.u4cys21077.EndSem;


import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;

abstract class File{
    private String fileName;
    private long fileSize;

    File(String fn, long fs){
        this.fileName = fn;
        this.fileSize = fs;
    }


    public String getFileName() { return this.fileName; }
    public double getFileSize() { return this.fileSize; }

    public double getFiles() { return this.fileSize; }

    public void setFileName(String name) { this.fileName = name; }
    public void setFileSize(long size) { this.fileSize = (long) (long) size; }

    public void setFiles(String name) { this.fileName = name; }

    public abstract void displayFileDetails();


    public abstract void addFile(File file);

    public abstract void deleteFile(String fileName);

    public abstract void displayAllFiles();


}

class Document extends File{
    private ArrayList<File> files;

    Document(String fn, long fs) {
        super(fn, fs);
    }

    public void FileManagementImp() {
        files = new ArrayList<>();
    }

    @Override
    public void displayFileDetails() {



    }

    @Override
    public void addFile(File file) {
        files.add(file);
    }

    @Override
    public void deleteFile(String fileName) {
        Iterator<File> it = files.iterator();
        while(it.hasNext()) {
            File f = it.next();
            if(f.getFileName().equals(fileName)) {
                it.remove();
                break;
            }
        }
    }

    @Override
    public void displayAllFiles() {
        for (File f : files) {
            f.displayFileDetails();
        }

    }


}

class Image extends File {
    private String resolution;
    Image(String fileName, long fileSize, String res)
    {
        super(fileName, fileSize);
        this.resolution = res;
    }

    public String getResolution() {
        return resolution;
    }

    public void setDocumentType(String type) { this.resolution = type; }

    @Override
    public void displayFileDetails() {
        System.out.println("File Name: " + getFileName() + ", File Size: " + getFileSize() + ", Resolution: " + getResolution());
    }

    @Override
    public void addFile(File file) {

    }

    @Override
    public void deleteFile(String fileName) {

    }

    @Override
    public void displayAllFiles() {

    }
}

class Video extends File{
    private long duration;
    Video(String fileName,long fileSize, long dur) {
        super(fileName, fileSize);
        this.duration = dur;
    }


    public double getDuration() {
        return duration;
    }

    public void setduration(String type) { this.duration = (long) Double.parseDouble(type); }

    @Override
    public void displayFileDetails() {
        System.out.println("File Name: " + getFileName() + ", File Size: " + getFileSize() + ", Duration: " + getDuration());
    }

    @Override
    public void addFile(File file) {

    }

    @Override
    public void deleteFile(String fileName) {

    }

    @Override
    public void displayAllFiles() {

    }
}

interface FileManager{

    void addFile(File file);

    void deleteFile(String fileName);

     void displayAllfiles();


}

class FileManagementImp implements FileManager{

    private ArrayList<File> files;

    public FileManagementImp() {
        files = new ArrayList<>();
    }

    @Override
    public void addFile(File file) {
        file.addFile(file);
    }

    @Override
    public void deleteFile(String fileName) {
     /*   Iterator<File> it = fileName.iterator();
        while(it.hasNext()) {
            File f = it.next();
            if(f.getFileName().equals(fileName)) {
                it.remove();
                break;
            }
        }
        */

    }

    @Override
    public void displayAllfiles() {

    }
}

public class FileManagementSystemUI extends JFrame {
    private JTable fileTable;
    private DefaultTableModel tableModel;
    private JTextField fileNameField, fileSizeField;
    private JComboBox<String> fileTypeBox;
    private FileManagementImp fileManager;

    public FileManagementSystemUI() {
        fileManager = new FileManagementImp();

        setTitle("21UCYS End Semester Assignment File Manager");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);

        createUI();

        setVisible(true);
    }

    private void createUI() {
        JPanel panel = new JPanel(new BorderLayout());


        tableModel = new DefaultTableModel();
        tableModel.addColumn("File Name");
        tableModel.addColumn("File Size");
        tableModel.addColumn("File Type");

        fileTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(fileTable);

        panel.add(scrollPane, BorderLayout.CENTER);


        JPanel inputPanel = new JPanel();

        fileNameField = new JTextField(10);
        inputPanel.add(new JLabel("File Name:"));
        inputPanel.add(fileNameField);

        fileSizeField = new JTextField(10);
        inputPanel.add(new JLabel("File Size:"));
        inputPanel.add(fileSizeField);

        String[] fileTypes = {"Document", "Image", "Video"};
        fileTypeBox = new JComboBox<>(fileTypes);
        inputPanel.add(new JLabel("File Type:"));
        inputPanel.add(fileTypeBox);

        JButton addFileButton = new JButton("Add File");
        addFileButton.addActionListener(e -> {

            tableModel.addRow(new Object[]{
                    fileNameField.getText(),
                    fileSizeField.getText(),
                    fileTypeBox.getSelectedItem().toString()
            });

        });

        JButton deleteFileButton = new JButton("Delete File");
        deleteFileButton.addActionListener(e -> {
            int selectedRow = fileTable.getSelectedRow();
            if (selectedRow != -1) {

                tableModel.removeRow(selectedRow);

            } else {
                JOptionPane.showMessageDialog(
                        FileManagementSystemUI.this,
                        "Please select a file to delete.",
                        "Delete File",
                        JOptionPane.WARNING_MESSAGE
                );
            }
        });

        inputPanel.add(addFileButton);
        inputPanel.add(deleteFileButton);

        panel.add(inputPanel, BorderLayout.SOUTH);


        add(panel);
    }


    public static void main(String[] args) {

        SwingUtilities.invokeLater(FileManagementSystemUI::new);
    }
}


