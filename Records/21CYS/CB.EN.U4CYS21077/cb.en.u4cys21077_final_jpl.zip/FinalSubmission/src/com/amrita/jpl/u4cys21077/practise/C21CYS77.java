package com.amrita.jpl.u4cys21077.practise;

public class C21CYS77 {
    /**
     * @author Sushmanth Murugan
     */

    //declare variable (attribute)
    static double assignGrade;

    //create a publishResult() method
    public static void publishResult(){
        System.out.println("Result are published");
    }

    /**
     * Assigns the Grade of the Student
     * @param grade grade Assigned to the Student
     */
    //Create a graded() method with a parameter
    public static void graded(double grade){
        System.out.println("Grade is:"+ grade);
    }

    /**
     * Main function
     * @param args Default argument to main function
     */
    //Modify the attribute and Call the methods on the myClass object
    public static void main(String[] args) {
        C21CYS77 myclass = new C21CYS77();
        publishResult();
        myclass.assignGrade=8.95;
        graded(myclass.assignGrade);

    }
}