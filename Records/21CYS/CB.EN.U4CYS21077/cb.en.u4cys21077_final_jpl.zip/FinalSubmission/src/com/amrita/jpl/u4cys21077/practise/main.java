package com.amrita.jpl.u4cys21077.practise;

public class main {
}
